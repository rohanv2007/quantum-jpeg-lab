# Quantum JPEG Lab

Quantum JPEG Lab is a local research workbench for comparing exact image-state preparation with Matrix Product State (MPS) truncation. The web interface is React and TanStack Start. Actual circuit construction, transpilation, and noisy simulation run in a Python service on the same PC.

## Quick start

Double-click `Start Quantum JPEG Lab.exe` in this folder. It starts the local simulation engine and web workbench, then opens the browser when both are ready. Keep the PowerShell window open while using the app; press Ctrl+C there to stop it. The first launch installs the Python and web dependencies and may take a few minutes.

## Run the local simulation

Requirements:

- Windows 10 or 11
- Python 3.11 or 3.12
- Node.js 20.19 or newer and npm

From this project folder, open PowerShell and run:

~~~powershell
powershell -ExecutionPolicy Bypass -File .\start-local.ps1
~~~

The first launch creates a Python virtual environment, installs the backend dependencies and web dependencies, starts the local engine, and starts the web workbench. Open the local address printed by the web development server. Stop the services with Ctrl+C.

The simulation service binds only to 127.0.0.1. Uploaded images and computed results are sent to that local service, not to a cloud simulation server. New run history and benchmark rows are stored in this browser's local storage.

## What a live run does

The Simulation Workbench and Benchmark Explorer send the selected, resized image channels and settings to http://127.0.0.1:8765. The local engine streams stage updates while it:

1. Orders and normalizes image amplitudes.
2. Performs right-to-left SVD truncation into MPS tensors.
3. Synthesizes sequential-isometry and exact state-preparation circuits.
4. Transpiles both circuits to the configured gate basis.
5. Runs both circuits through Qiskit Aer. When noise is enabled, CNOTs receive the configured depolarizing error and physical SX/X/CX pulses receive T1/T2 relaxation; virtual RZ gates have zero duration. The Noiseless preset disables every noise channel.
6. If noise is enabled, reruns each exact/MPS circuit with 0.5× and 1.5× versions of the configured noise, then uses quadratic zero-noise extrapolation to estimate a cleaner output. It projects the extrapolated probabilities onto a valid distribution before rebuilding the image.
7. Returns the original MPS approximation, raw noisy exact/MPS outputs, and cleaned estimates, then calculates fidelity, PSNR, SSIM, and compiled CNOT counts.

Progress updates report real stage changes. Aer may not expose a meaningful percentage while a single circuit is running, so the workbench shows the active circuit and elapsed time instead of a made-up percentage.

The local engine uses the PC CPU unless the installed Qiskit Aer package reports a compatible GPU. The selected device and Qiskit/Aer versions are recorded with each result. These are software simulations, not measurements from physical quantum hardware.

The “cleaned estimate” is model based: it uses the noise settings you entered and compares simulations at three noise strengths. It does not detect unknown noise on a real device. Extrapolation can improve similarity, but is not guaranteed to do so, and the extra simulations take additional time. PSNR and SSIM are evaluated against the input image because this simulator knows the original; a real recovery task may not have that reference.

For RGB input, each color channel is encoded and simulated independently. State fidelity and SSIM are averaged across channels; PSNR is computed across the combined RGB pixel values. Gate counts are reported per channel. The sample image is procedural; bundled benchmark points are historical records from an earlier noise model and should not be directly compared with current local runs.

The simulation validates the compiled exact loader against the normalized input state and validates the compiled MPS loader against the contracted MPS state before Aer runs. The four-way image comparison separates exact-loader noise, MPS truncation, and noise on the MPS circuit. Ideal-mode exact output acts as a round-trip check. A low-χ MPS image is still expected to lose detail because the bond dimension limits the retained correlations.

## Start the services separately

If you prefer to manage the processes yourself, start the Python engine from the project folder:

~~~powershell
py -3.11 -m venv backend\.venv
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
backend\.venv\Scripts\python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8765
~~~

In another PowerShell window, install and run the frontend:

~~~powershell
npm install
npm run dev -- --host 127.0.0.1
~~~

The service health and runtime versions are available at http://127.0.0.1:8765/api/health.

## Research limits

- Only 16×16 and 32×32 images are supported by the current circuit pipeline.
- Noise settings are a configurable Aer model, not device calibration.
- RGB channels use independent amplitude encoding; YCbCr, ROI compression, and QNN experiments are not implemented.
- The app keeps earlier measured records visibly separate from newly computed local Aer runs.
- PSNR is capped at 100 dB for display when reconstruction error is zero.

## Development

~~~sh
npm install
npm run dev
~~~

