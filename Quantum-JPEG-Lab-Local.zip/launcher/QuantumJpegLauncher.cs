using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

internal static class QuantumJpegLauncher
{
    private const string AppUrl = "http://127.0.0.1:8080/simulation";
    private const string EngineUrl = "http://127.0.0.1:8765/api/health";

    private static int Main()
    {
        string projectRoot = AppDomain.CurrentDomain.BaseDirectory;
        string startupScript = Path.Combine(projectRoot, "start-local.ps1");

        if (!File.Exists(startupScript))
        {
            Console.Error.WriteLine("Could not find start-local.ps1 beside this launcher.");
            Console.Error.WriteLine("Keep this launcher in the main Quantum JPEG Lab project folder.");
            PauseBeforeExit();
            return 1;
        }

        if (IsReady(AppUrl, null) && IsReady(EngineUrl, "local-qiskit-aer"))
        {
            Console.WriteLine("Quantum JPEG Lab is already running. Opening the workbench...");
            OpenBrowser();
            return 0;
        }

        string powershell = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe");
        string escapedScript = startupScript.Replace("\"", "\"\"");

        var startInfo = new ProcessStartInfo
        {
            FileName = powershell,
            Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + escapedScript + "\"",
            WorkingDirectory = projectRoot,
            UseShellExecute = false,
            CreateNoWindow = false
        };

        Process startup;
        try
        {
            startup = Process.Start(startInfo);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("Could not start the local services: " + ex.Message);
            PauseBeforeExit();
            return 1;
        }

        Console.WriteLine("Starting the local Python engine and web workbench...");
        Console.WriteLine("The first launch may take a few minutes while dependencies install.");

        DateTime deadline = DateTime.UtcNow.AddMinutes(30);
        while (DateTime.UtcNow < deadline)
        {
            if (IsReady(AppUrl, null) && IsReady(EngineUrl, "local-qiskit-aer"))
            {
                Console.WriteLine("The simulator is ready. Opening the workbench in your browser...");
                OpenBrowser();
                return 0;
            }

            if (startup.HasExited)
            {
                Console.Error.WriteLine("The startup script stopped before both services were ready.");
                Console.Error.WriteLine("Read the messages above for the missing dependency or startup error.");
                PauseBeforeExit();
                return 1;
            }

            Thread.Sleep(1000);
        }

        Console.Error.WriteLine("Startup timed out. Check the PowerShell messages above, then run the launcher again.");
        PauseBeforeExit();
        return 1;
    }

    private static bool IsReady(string url, string expectedText)
    {
        try
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.Timeout = 1200;
            request.ReadWriteTimeout = 1200;
            using (var response = (HttpWebResponse)request.GetResponse())
            using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            {
                string body = reader.ReadToEnd();
                return response.StatusCode == HttpStatusCode.OK &&
                    (expectedText == null || body.IndexOf(expectedText, StringComparison.OrdinalIgnoreCase) >= 0);
            }
        }
        catch
        {
            return false;
        }
    }

    private static void OpenBrowser()
    {
        try
        {
            Process.Start(new ProcessStartInfo { FileName = AppUrl, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("The app is running, but the browser did not open: " + ex.Message);
            Console.WriteLine("Open this address manually: " + AppUrl);
            PauseBeforeExit();
        }
    }

    private static void PauseBeforeExit()
    {
        Console.WriteLine("Press any key to close this window.");
        try { Console.ReadKey(true); } catch { }
    }
}
