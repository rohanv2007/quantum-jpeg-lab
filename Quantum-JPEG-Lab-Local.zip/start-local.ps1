$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$venvPath = Join-Path $projectRoot "backend\.venv"
$localPython = Join-Path $venvPath "Scripts\python.exe"
$stdoutPath = Join-Path $projectRoot "backend\local-engine.out.log"
$stderrPath = Join-Path $projectRoot "backend\local-engine.err.log"
$backendProcess = $null

Set-Location -LiteralPath $projectRoot

if (-not (Test-Path -LiteralPath $localPython)) {
    $pythonLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($pythonLauncher) {
        $installedPythonVersions = & $pythonLauncher.Source -0p 2>$null | Out-String
        if ($installedPythonVersions -match "3\.11") {
            & $pythonLauncher.Source -3.11 -m venv $venvPath
        } elseif ($installedPythonVersions -match "3\.12") {
            & $pythonLauncher.Source -3.12 -m venv $venvPath
        } else {
            throw "Install Python 3.11 or 3.12, then run this script again."
        }
    } else {
        & python -m venv $venvPath
    }
    if ($LASTEXITCODE -ne 0) {
        throw "Could not create the Python environment. Install Python 3.11 or 3.12 and try again."
    }
}

$pythonVersion = & $localPython -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
if ($pythonVersion -notin @("3.11", "3.12")) {
    throw "Use Python 3.11 or 3.12 for the local Qiskit engine. Detected Python $pythonVersion."
}

Write-Host "Installing local Qiskit simulation dependencies..."
& $localPython -m pip install -r (Join-Path $projectRoot "backend\requirements.txt")
if ($LASTEXITCODE -ne 0) {
    throw "Installing the Python dependencies failed."
}

if (-not (Test-Path -LiteralPath (Join-Path $projectRoot "node_modules"))) {
    Write-Host "Installing web workbench dependencies..."
    & npm install --no-package-lock
    if ($LASTEXITCODE -ne 0) {
        throw "Installing the web dependencies failed."
    }
}

Write-Host "Starting the local Qiskit Aer service..."
$backendProcess = Start-Process -FilePath $localPython -ArgumentList @("-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1", "--port", "8765") -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath

$engineReady = $false
for ($attempt = 0; $attempt -lt 45; $attempt++) {
    try {
        $engineHealth = Invoke-RestMethod -Uri "http://127.0.0.1:8765/api/health" -TimeoutSec 2
        if ($engineHealth.engine -eq "local-qiskit-aer") {
            $engineReady = $true
            break
        }
    } catch {
        # The Python service can take a moment to initialize.
    }
    if ($backendProcess.HasExited) { break }
    Start-Sleep -Milliseconds 1000
}

if (-not $engineReady) {
    if (-not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -Force
    }
    Write-Host "Local engine startup log: $stderrPath"
    throw "The local simulation engine did not start. Check the backend log and install Python 3.11 or newer."
}

Write-Host "Local engine ready. Starting the web workbench..."
Write-Host "Open the local URL printed below. Press Ctrl+C to stop both services."

try {
    & npm run dev -- --host 127.0.0.1
} finally {
    if ($backendProcess -and -not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -Force
    }
}
