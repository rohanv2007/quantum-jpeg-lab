from __future__ import annotations

import asyncio
import json
import math
import queue
import threading
import time
from importlib.metadata import PackageNotFoundError, version
from typing import Literal

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import Isometry, StatePreparation
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    thermal_relaxation_error,
)
from scipy.linalg import null_space
from skimage.metrics import structural_similarity


Ordering = Literal["row-major", "z-order", "hilbert"]
Chi = Literal[1, 2, 4, 8]


class NoiseSettings(BaseModel):
    enabled: bool = True
    eps_cx: float = Field(ge=0, le=1)
    t1_us: float = Field(gt=0)
    t2_us: float = Field(gt=0)
    cx_duration_ns: float = Field(gt=0)
    one_q_duration_ns: float = Field(gt=0)


class SimulationRequest(BaseModel):
    size: Literal[16, 32]
    channels: list[list[float]]
    ordering: Ordering
    chi: Chi
    noise: NoiseSettings
    basis: str = "rz, sx, x, cx"
    optimization_level: int = Field(default=1, ge=0, le=3)
    image_name: str = Field(default="User image", max_length=160)


app = FastAPI(title="Quantum JPEG Local Engine", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

_run_lock = threading.Lock()


def _package_version(name: str) -> str:
    try:
        return version(name)
    except PackageNotFoundError:
        return "unknown"


@app.get("/api/health")
def health() -> dict[str, object]:
    try:
        devices = [str(item) for item in AerSimulator.available_devices()]
    except Exception:
        devices = ["CPU"]
    default_device = "GPU" if "GPU" in devices else "CPU"
    return {
        "status": "ready",
        "engine": "local-qiskit-aer",
        "qiskit": _package_version("qiskit"),
        "aer": _package_version("qiskit-aer"),
        "numpy": np.__version__,
        "devices": devices,
        "defaultDevice": default_device,
    }


def _report(report, stage: int, label: str, detail: str) -> None:
    report({"type": "stage", "stage": stage, "label": label, "detail": detail})


def _d2xy(size: int, distance: int) -> tuple[int, int]:
    x = 0
    y = 0
    t = distance
    scale = 1
    while scale < size:
        rx = 1 & (t // 2)
        ry = 1 & (t ^ rx)
        if ry == 0:
            if rx == 1:
                x = scale - 1 - x
                y = scale - 1 - y
            x, y = y, x
        x += scale * rx
        y += scale * ry
        t //= 4
        scale *= 2
    return x, y


def _pixel_permutation(size: int, ordering: Ordering) -> np.ndarray:
    positions: list[int] = []
    for d in range(size * size):
        if ordering == "row-major":
            x, y = d % size, d // size
        elif ordering == "z-order":
            x = y = 0
            bit = 0
            value = d
            while value:
                x |= (value & 1) << bit
                y |= ((value >> 1) & 1) << bit
                value >>= 2
                bit += 1
        else:
            x, y = _d2xy(size, d)
        positions.append(y * size + x)
    permutation = np.asarray(positions, dtype=np.int64)
    if len(np.unique(permutation)) != size * size:
        raise ValueError(f"The {ordering} ordering did not produce a valid pixel permutation.")
    return permutation


def _normalize_channel(channel: np.ndarray, permutation: np.ndarray) -> tuple[np.ndarray, float]:
    ordered = channel.reshape(-1)[permutation].astype(np.float64, copy=False)
    scale = float(np.linalg.norm(ordered))
    if scale < 1e-12:
        state = np.zeros_like(ordered)
        state[0] = 1.0
        return state, 0.0
    return ordered / scale, scale


def _bond_bits(chi: int) -> int:
    return 0 if chi <= 1 else int(math.ceil(math.log2(chi)))


def _state_to_mps(state: np.ndarray, qubits: int, chi_max: int) -> list[np.ndarray]:
    tensor = state.reshape((2,) * qubits).transpose(tuple(range(qubits - 1, -1, -1)))
    matrix = tensor.reshape(2 ** (qubits - 1), 2)
    right_bond = 1
    tensors: list[np.ndarray | None] = [None] * qubits

    for site in range(qubits - 1, 0, -1):
        matrix = matrix.reshape(-1, 2 * right_bond)
        u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
        threshold = 1e-12 * singular_values[0] if singular_values.size else 0.0
        keep = int(max(1, min(chi_max, np.count_nonzero(singular_values > threshold))))
        tensors[site] = vh[:keep].reshape(keep, 2, right_bond)
        matrix = u[:, :keep] * singular_values[:keep]
        right_bond = keep

    left = matrix / np.linalg.norm(matrix)
    tensors[0] = left.reshape(1, 2, right_bond)
    return [np.asarray(tensor) for tensor in tensors]


def _mps_to_state(tensors: list[np.ndarray]) -> np.ndarray:
    result = tensors[0]
    for tensor in tensors[1:]:
        result = np.tensordot(result, tensor, axes=([-1], [0]))
    qubits = len(tensors)
    state = result.reshape((2,) * qubits).transpose(tuple(range(qubits - 1, -1, -1))).reshape(-1)
    norm = np.linalg.norm(state)
    return state / norm if norm else state


def _isometry_matrix(tensor: np.ndarray) -> np.ndarray:
    chi_in, _, chi_out = tensor.shape
    input_bits = _bond_bits(chi_in)
    output_bits = _bond_bits(chi_out)
    matrix = np.zeros((2 ** (output_bits + 1), 2 ** input_bits), dtype=np.float64)
    for bond_in in range(chi_in):
        for physical in range(2):
            for bond_out in range(chi_out):
                matrix[physical + 2 * bond_out, bond_in] = tensor[bond_in, physical, bond_out]
    missing = 2 ** input_bits - chi_in
    if missing:
        matrix[:, chi_in:] = null_space(matrix[:, :chi_in].T)[:, :missing]
    return matrix


def _mps_to_circuit(tensors: list[np.ndarray]) -> QuantumCircuit:
    qubits = len(tensors)
    circuit = QuantumCircuit(qubits)
    for site, tensor in enumerate(tensors):
        isometry = _isometry_matrix(tensor)
        input_bits = _bond_bits(tensor.shape[0])
        operation_qubits = _bond_bits(tensor.shape[2]) + 1
        targets = list(range(site, site + operation_qubits))
        if input_bits == 0:
            circuit.append(StatePreparation(isometry[:, 0]), targets)
        else:
            circuit.append(Isometry(isometry, num_ancillas_zero=0, num_ancillas_dirty=0), targets)
    return circuit


def _basis_gates(basis: str) -> list[str]:
    gates = [gate.strip().lower() for gate in basis.split(",") if gate.strip()]
    supported = {"rz", "sx", "x", "cx"}
    if not gates or len(set(gates)) != len(gates) or not set(gates).issubset(supported):
        raise ValueError("Supported transpilation gates are rz, sx, x, and cx.")
    if "cx" not in gates:
        raise ValueError("The basis must include cx so compiled two-qubit gate counts can be measured.")
    return gates


def _make_noise_model(settings: NoiseSettings) -> NoiseModel:
    if not settings.enabled:
        return NoiseModel()
    t1 = settings.t1_us * 1e-6
    t2 = settings.t2_us * 1e-6
    if t2 > 2 * t1:
        raise ValueError("T2 must be at most 2 × T1 for a valid relaxation model.")
    one_q_duration = settings.one_q_duration_ns * 1e-9
    cx_duration = settings.cx_duration_ns * 1e-9
    one_q_relaxation = thermal_relaxation_error(t1, t2, one_q_duration)
    cx_relaxation = one_q_relaxation if math.isclose(cx_duration, one_q_duration) else thermal_relaxation_error(t1, t2, cx_duration)
    # RZ is a virtual frame change on the target basis and has no pulse duration.
    # εcx is explicitly a two-qubit error rate; do not silently derive a 1q error from it.
    cx_error = depolarizing_error(settings.eps_cx, 2).compose(cx_relaxation.tensor(cx_relaxation))
    model = NoiseModel()
    model.add_all_qubit_quantum_error(one_q_relaxation, ["sx", "x"])
    model.add_all_qubit_quantum_error(cx_error, ["cx"])
    return model


def _scaled_noise_settings(settings: NoiseSettings, factor: float) -> NoiseSettings:
    """Scale configured gate noise for zero-noise extrapolation replicas."""
    return settings.model_copy(
        update={
            "eps_cx": min(settings.eps_cx * factor, 1.0),
            "cx_duration_ns": settings.cx_duration_ns * factor,
            "one_q_duration_ns": settings.one_q_duration_ns * factor,
        }
    )


def _project_probability_simplex(values: np.ndarray) -> np.ndarray:
    """Project extrapolated values onto valid nonnegative, unit-sum probabilities."""
    values = np.asarray(values, dtype=np.float64)
    ordered = np.sort(values)[::-1]
    cumulative = np.cumsum(ordered) - 1.0
    indices = np.arange(1, len(values) + 1, dtype=np.float64)
    valid = ordered - cumulative / indices > 0
    rho = int(np.flatnonzero(valid)[-1])
    threshold = cumulative[rho] / (rho + 1)
    projected = np.maximum(values - threshold, 0.0)
    total = float(projected.sum())
    return projected / total if total > 0 else np.full_like(projected, 1.0 / len(projected))


def _zero_noise_probabilities(
    circuit: QuantumCircuit,
    baseline_density: np.ndarray,
    settings: NoiseSettings,
    seed: int,
    device: str,
    report,
    label: str,
) -> np.ndarray:
    """Estimate zero-noise basis probabilities from 0.5x, 1x, and 1.5x runs."""
    half_model = _make_noise_model(_scaled_noise_settings(settings, 0.5))
    high_model = _make_noise_model(_scaled_noise_settings(settings, 1.5))
    report({"type": "stage", "stage": 3, "label": "Noise mitigation", "detail": f"Measuring a 0.5× noise replica for {label}."})
    half_density = _run_density_matrix(circuit, half_model, seed + 1000, device)
    report({"type": "stage", "stage": 3, "label": "Noise mitigation", "detail": f"Measuring a 1.5× noise replica for {label}."})
    high_density = _run_density_matrix(circuit, high_model, seed + 2000, device)
    p_half = np.real(np.diag(half_density))
    p_base = np.real(np.diag(baseline_density))
    p_high = np.real(np.diag(high_density))
    # Quadratic Richardson extrapolation to zero noise: 3*p(0.5)-3*p(1)+p(1.5).
    # Noise amplification can create negative entries, so project back to the
    # nearest valid probability vector before decoding it as image amplitudes.
    return _project_probability_simplex(3.0 * p_half - 3.0 * p_base + p_high)


def _fidelity(state: np.ndarray, density: np.ndarray) -> float:
    value = np.vdot(state, density @ state).real
    return float(np.clip(value, 0.0, 1.0))


def _reconstruct_channel(
    density: np.ndarray, permutation: np.ndarray, scale: float, size: int
) -> np.ndarray:
    if scale == 0:
        return np.zeros(size * size, dtype=np.float64)
    probabilities = np.clip(np.real(np.diag(density)), 0.0, 1.0)
    return _reconstruct_probabilities(probabilities, permutation, scale, size)


def _reconstruct_probabilities(
    probabilities: np.ndarray, permutation: np.ndarray, scale: float, size: int
) -> np.ndarray:
    if scale == 0:
        return np.zeros(size * size, dtype=np.float64)
    probabilities = np.clip(probabilities, 0.0, 1.0)
    total = float(probabilities.sum())
    if total > 0:
        probabilities = probabilities / total
    return _reconstruct_amplitudes(np.sqrt(probabilities), permutation, scale, size)


def _reconstruct_amplitudes(
    amplitudes: np.ndarray, permutation: np.ndarray, scale: float, size: int
) -> np.ndarray:
    if scale == 0:
        return np.zeros(size * size, dtype=np.float64)
    ordered_pixels = np.abs(amplitudes) * scale
    pixels = np.zeros(size * size, dtype=np.float64)
    pixels[permutation] = ordered_pixels
    return np.clip(pixels, 0.0, 1.0)


def _psnr(original: np.ndarray, reconstructed: np.ndarray) -> float:
    mse = float(np.mean((original - reconstructed) ** 2))
    # Output pixels are serialized to six decimals, so treat sub-picometric
    # residuals as a perfect reconstruction instead of reporting 150–200 dB.
    if mse <= 1e-12:
        return 100.0
    return float(10 * np.log10(1.0 / mse))


def _image_metrics(original: np.ndarray, reconstructed: np.ndarray, size: int) -> tuple[float, float]:
    original_2d = original.reshape(size, size)
    reconstructed_2d = reconstructed.reshape(size, size)
    return (
        _psnr(original_2d, reconstructed_2d),
        float(np.clip(structural_similarity(original_2d, reconstructed_2d, data_range=1.0), 0.0, 1.0)),
    )


def _rounded_channels(channels: list[np.ndarray]) -> list[list[float]]:
    return [np.round(channel, 6).astype(np.float32).tolist() for channel in channels]


def _run_density_matrix(circuit: QuantumCircuit, noise_model: NoiseModel, seed: int, device: str) -> np.ndarray:
    executable = circuit.copy()
    executable.save_density_matrix()
    simulator = AerSimulator(method="density_matrix", noise_model=noise_model, device=device)
    result = simulator.run(executable, seed_simulator=seed).result()
    if not result.success:
        raise RuntimeError(result.status or "Aer density-matrix simulation failed.")
    return np.asarray(result.data(0)["density_matrix"], dtype=np.complex128)


def _simulate(payload: SimulationRequest, report) -> dict[str, object]:
    started = time.perf_counter()
    size = payload.size
    qubits = int(math.log2(size * size))
    if len(payload.channels) not in (1, 3):
        raise ValueError("Provide one grayscale channel or three RGB channels.")
    if any(len(channel) != size * size for channel in payload.channels):
        raise ValueError(f"Each image channel must contain exactly {size * size} pixels.")
    channel_arrays = [np.asarray(channel, dtype=np.float64) for channel in payload.channels]
    if any(not np.all(np.isfinite(channel)) or np.any(channel < 0) or np.any(channel > 1) for channel in channel_arrays):
        raise ValueError("Image pixels must be finite values from 0 to 1.")
    basis = _basis_gates(payload.basis)
    permutation = _pixel_permutation(size, payload.ordering)

    _report(report, 0, "Preprocessing", f"Ordering and normalizing {len(channel_arrays)} image channel(s).")
    prepared = [_normalize_channel(channel, permutation) for channel in channel_arrays]
    original_states = [entry[0] for entry in prepared]
    scales = [entry[1] for entry in prepared]

    _report(report, 1, "MPS truncation", f"Performing right-to-left SVD truncation at χ={payload.chi}.")
    mps_tensors = [_state_to_mps(state, qubits, payload.chi) for state in original_states]
    mps_states = [_mps_to_state(tensors) for tensors in mps_tensors]

    _report(report, 2, "Circuit synthesis", f"Building exact and sequential-isometry circuits; transpiling to {', '.join(basis)}.")
    exact_circuits: list[QuantumCircuit] = []
    mps_circuits: list[QuantumCircuit] = []
    exact_counts: list[int] = []
    mps_counts: list[int] = []
    exact_circuit_fidelities: list[float] = []
    circuit_fidelities: list[float] = []
    for state, approximate, tensors in zip(original_states, mps_states, mps_tensors, strict=True):
        exact_source = QuantumCircuit(qubits)
        exact_source.append(StatePreparation(state), list(range(qubits)))
        exact = transpile(
            exact_source,
            basis_gates=basis,
            optimization_level=payload.optimization_level,
            seed_transpiler=7,
        )
        exact_state = Statevector.from_instruction(exact).data
        exact_circuit_fidelities.append(float(np.clip(abs(np.vdot(state, exact_state)) ** 2, 0.0, 1.0)))
        mps = _mps_to_circuit(tensors)
        mps = transpile(
            mps,
            basis_gates=basis,
            optimization_level=payload.optimization_level,
            seed_transpiler=7,
        )
        # Check the compiled circuit, rather than only the unsynthesized MPS
        # preparation. This catches ordering and transpilation regressions.
        circuit_state = Statevector.from_instruction(mps).data
        circuit_fidelities.append(float(np.clip(abs(np.vdot(approximate, circuit_state)) ** 2, 0.0, 1.0)))
        if exact_circuit_fidelities[-1] < 1.0 - 1e-9:
            raise RuntimeError("The compiled exact loader failed its image-state round-trip check.")
        if circuit_fidelities[-1] < 1.0 - 1e-9:
            raise RuntimeError("The compiled MPS loader does not reproduce its contracted MPS state.")
        exact_circuits.append(exact)
        mps_circuits.append(mps)
        exact_counts.append(int(exact.count_ops().get("cx", 0)))
        mps_counts.append(int(mps.count_ops().get("cx", 0)))

    noise_description = (
        "Noise is disabled for an ideal round-trip reference."
        if not payload.noise.enabled
        else "Applying CNOT depolarization and T1/T2 relaxation to physical SX, X, and CX pulses; virtual RZ gates have zero duration."
    )
    _report(report, 3, "Aer noise simulation", noise_description)
    noise_model = _make_noise_model(payload.noise)
    try:
        available_devices = {str(item) for item in AerSimulator.available_devices()}
    except Exception:
        available_devices = {"CPU"}
    device = "GPU" if "GPU" in available_devices else "CPU"
    exact_densities: list[np.ndarray] = []
    mps_densities: list[np.ndarray] = []
    exact_mitigated_probabilities: list[np.ndarray] = []
    mps_mitigated_probabilities: list[np.ndarray] = []
    for index, (exact, mps) in enumerate(zip(exact_circuits, mps_circuits, strict=True)):
        channel_name = ("R", "G", "B")[index] if len(channel_arrays) == 3 else "grayscale"
        report({"type": "stage", "stage": 3, "label": "Aer noise simulation", "detail": f"Running exact-loader circuit for {channel_name} on this PC's {device}."})
        exact_densities.append(_run_density_matrix(exact, noise_model, 17 + index, device))
        report({"type": "stage", "stage": 3, "label": "Aer noise simulation", "detail": f"Running χ={payload.chi} MPS circuit for {channel_name} on this PC's {device}."})
        mps_densities.append(_run_density_matrix(mps, noise_model, 31 + index, device))
        if payload.noise.enabled:
            exact_mitigated_probabilities.append(
                _zero_noise_probabilities(
                    exact, exact_densities[-1], payload.noise, 117 + index, device, report, f"exact {channel_name} circuit"
                )
            )
            mps_mitigated_probabilities.append(
                _zero_noise_probabilities(
                    mps, mps_densities[-1], payload.noise, 131 + index, device, report, f"χ={payload.chi} MPS {channel_name} circuit"
                )
            )

    _report(report, 4, "Reconstruction", "Converting noisy density-matrix probabilities back to image pixels.")
    exact_images = [
        _reconstruct_channel(density, permutation, scale, size)
        for density, scale in zip(exact_densities, scales, strict=True)
    ]
    mps_images = [
        _reconstruct_channel(density, permutation, scale, size)
        for density, scale in zip(mps_densities, scales, strict=True)
    ]
    mps_ideal_images = [
        _reconstruct_amplitudes(state, permutation, scale, size)
        for state, scale in zip(mps_states, scales, strict=True)
    ]
    exact_mitigated_images = [
        _reconstruct_probabilities(probabilities, permutation, scale, size)
        for probabilities, scale in zip(exact_mitigated_probabilities, scales, strict=True)
    ] if payload.noise.enabled else []
    mps_mitigated_images = [
        _reconstruct_probabilities(probabilities, permutation, scale, size)
        for probabilities, scale in zip(mps_mitigated_probabilities, scales, strict=True)
    ] if payload.noise.enabled else []

    _report(report, 5, "Scoring", "Calculating state fidelity, PSNR, SSIM, and compiled CNOT counts.")
    exact_fidelities = [_fidelity(state, density) for state, density in zip(original_states, exact_densities, strict=True)]
    mps_fidelities = [_fidelity(state, density) for state, density in zip(original_states, mps_densities, strict=True)]
    ideal_fidelities = [float(np.clip(abs(np.vdot(state, approximate)) ** 2, 0.0, 1.0)) for state, approximate in zip(original_states, mps_states, strict=True)]
    exact_quality = [
        _image_metrics(original, reconstructed, size)
        for original, reconstructed in zip(channel_arrays, exact_images, strict=True)
    ]
    mps_quality = [
        _image_metrics(original, reconstructed, size)
        for original, reconstructed in zip(channel_arrays, mps_images, strict=True)
    ]
    exact_mitigated_quality = [
        _image_metrics(original, reconstructed, size)
        for original, reconstructed in zip(channel_arrays, exact_mitigated_images, strict=True)
    ] if payload.noise.enabled else []
    mps_mitigated_quality = [
        _image_metrics(original, reconstructed, size)
        for original, reconstructed in zip(channel_arrays, mps_mitigated_images, strict=True)
    ] if payload.noise.enabled else []
    average = lambda values: float(np.mean(values)) if values else 0.0
    channel_labels = ("R", "G", "B") if len(channel_arrays) == 3 else ("grayscale",)
    per_channel = [
        {
            "channel": channel_labels[index],
            "exactCnots": exact_counts[index],
            "mpsCnots": mps_counts[index],
            "exactNoisyFidelity": exact_fidelities[index],
            "exactCircuitFidelity": exact_circuit_fidelities[index],
            "mpsNoisyFidelity": mps_fidelities[index],
            "mpsIdealFidelity": ideal_fidelities[index],
            "circuitVsMps": circuit_fidelities[index],
        }
        for index in range(len(channel_arrays))
    ]

    return {
        "exact": {"channels": _rounded_channels(exact_images)},
        "mpsIdeal": {"channels": _rounded_channels(mps_ideal_images)},
        "mps": {"channels": _rounded_channels(mps_images)},
        "exactMitigated": {"channels": _rounded_channels(exact_mitigated_images)} if payload.noise.enabled else None,
        "mpsMitigated": {"channels": _rounded_channels(mps_mitigated_images)} if payload.noise.enabled else None,
        "mitigation": {
            "applied": payload.noise.enabled,
            "method": "Quadratic zero-noise extrapolation using 0.5x, 1x, and 1.5x noise replicas",
            "note": "Uses the configured noise model. Extrapolated probabilities are projected to a valid distribution; image recovery is an estimate, not guaranteed reconstruction.",
        },
        "metrics": {
            "exactCnots": average(exact_counts),
            "mpsCnots": average(mps_counts),
            "exactNoisyFidelity": average(exact_fidelities),
            "mpsNoisyFidelity": average(mps_fidelities),
            "mpsIdealFidelity": average(ideal_fidelities),
            "circuitVsMps": average(circuit_fidelities),
            "exactPsnr": _psnr(np.concatenate(channel_arrays), np.concatenate(exact_images)),
            "mpsPsnr": _psnr(np.concatenate(channel_arrays), np.concatenate(mps_images)),
            "exactSsim": average([item[1] for item in exact_quality]),
            "mpsSsim": average([item[1] for item in mps_quality]),
            "exactMitigatedPsnr": _psnr(np.concatenate(channel_arrays), np.concatenate(exact_mitigated_images)) if payload.noise.enabled else 0.0,
            "exactMitigatedSsim": average([item[1] for item in exact_mitigated_quality]),
            "mpsMitigatedPsnr": _psnr(np.concatenate(channel_arrays), np.concatenate(mps_mitigated_images)) if payload.noise.enabled else 0.0,
            "mpsMitigatedSsim": average([item[1] for item in mps_mitigated_quality]),
        },
        "provenance": {
            "engine": "Local Qiskit Aer density-matrix simulation",
            "qiskitVersion": _package_version("qiskit"),
            "aerVersion": _package_version("qiskit-aer"),
            "device": device,
            "numpyVersion": np.__version__,
            "scikitImageVersion": _package_version("scikit-image"),
            "imageName": payload.image_name,
            "channelEncoding": "Independent amplitude encoding per image channel; RGB metrics are channel averages.",
            "ordering": payload.ordering,
            "chi": payload.chi,
            "noise": payload.noise.model_dump(),
            "noiseApplied": payload.noise.enabled,
            "noiseModelDescription": noise_description,
            "basis": basis,
            "optimizationLevel": payload.optimization_level,
            "perChannel": per_channel,
            "elapsedSeconds": round(time.perf_counter() - started, 3),
        },
    }


def _sse(event: dict[str, object]) -> str:
    return f"data: {json.dumps(event, separators=(',', ':'), allow_nan=False)}\n\n"


@app.post("/api/simulate/stream")
async def simulate_stream(payload: SimulationRequest) -> StreamingResponse:
    if not _run_lock.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="A local simulation is already running. Wait for it to finish and try again.")

    events: queue.Queue[dict[str, object]] = queue.Queue()
    finished = threading.Event()

    def worker() -> None:
        try:
            result = _simulate(payload, events.put)
            events.put({"type": "result", "result": result})
        except Exception as error:  # surfaced to the local UI; full details remain in the terminal log
            events.put({"type": "error", "message": str(error) or error.__class__.__name__})
            print(f"Local Qiskit simulation failed: {error}", flush=True)
        finally:
            finished.set()
            _run_lock.release()

    thread = threading.Thread(target=worker, name="quantum-jpeg-simulation", daemon=True)
    thread.start()

    async def stream_events():
        started = time.perf_counter()
        yield _sse({"type": "stage", "stage": 0, "label": "Starting", "detail": "Starting a simulation on this PC."})
        while True:
            try:
                event = await asyncio.to_thread(events.get, True, 1.0)
            except queue.Empty:
                if finished.is_set():
                    break
                yield _sse({"type": "heartbeat", "elapsedSeconds": round(time.perf_counter() - started)})
                continue
            yield _sse(event)
            if event.get("type") in ("result", "error"):
                break

    return StreamingResponse(
        stream_events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"},
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="127.0.0.1", port=8765, reload=False)
