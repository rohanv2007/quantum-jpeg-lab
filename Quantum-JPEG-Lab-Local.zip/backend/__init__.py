"""Local Quantum JPEG simulation service."""
