import unittest

import numpy as np
from qiskit.quantum_info import Statevector

from backend.main import (
    NoiseSettings,
    SimulationRequest,
    _make_noise_model,
    _mps_to_circuit,
    _mps_to_state,
    _pixel_permutation,
    _project_probability_simplex,
    _simulate,
    _state_to_mps,
)


class ImagePipelineTests(unittest.TestCase):
    def test_spatial_orders_are_bijections(self):
        for size in (16, 32):
            for ordering in ("row-major", "z-order", "hilbert"):
                with self.subTest(size=size, ordering=ordering):
                    permutation = _pixel_permutation(size, ordering)
                    np.testing.assert_array_equal(np.sort(permutation), np.arange(size * size))

    def test_compiled_mps_circuit_matches_contracted_state(self):
        rng = np.random.default_rng(11)
        for size in (16, 32):
            qubits = int(np.log2(size * size))
            state = rng.random(size * size)
            state /= np.linalg.norm(state)
            for chi in (1, 2, 4, 8):
                with self.subTest(size=size, chi=chi):
                    tensors = _state_to_mps(state, qubits, chi)
                    expected = _mps_to_state(tensors)
                    actual = Statevector.from_instruction(_mps_to_circuit(tensors)).data
                    self.assertGreaterEqual(abs(np.vdot(expected, actual)) ** 2, 1.0 - 1e-9)

    def test_noiseless_aer_exact_loader_round_trips_pixels(self):
        size = 16
        y, x = np.mgrid[:size, :size]
        image = np.clip(0.12 + 0.025 * x + 0.018 * y, 0.0, 1.0)
        image[2:6, 3:5] = 0.92
        image[10:14, 9:14] = 0.0
        image[8, 2] = 1.0
        payload = SimulationRequest(
            size=size,
            channels=[image.ravel().tolist()],
            ordering="row-major",
            chi=2,
            noise=NoiseSettings(
                enabled=False,
                eps_cx=0.0,
                t1_us=150,
                t2_us=100,
                cx_duration_ns=300,
                one_q_duration_ns=35,
            ),
        )
        result = _simulate(payload, lambda _event: None)
        exact = np.asarray(result["exact"]["channels"][0]).reshape(size, size)
        mps_ideal = np.asarray(result["mpsIdeal"]["channels"][0])
        mps_aer = np.asarray(result["mps"]["channels"][0])

        np.testing.assert_allclose(exact, image, atol=1e-6)
        np.testing.assert_allclose(mps_aer, mps_ideal, atol=1e-6)
        self.assertAlmostEqual(result["metrics"]["exactNoisyFidelity"], 1.0, places=8)
        self.assertEqual(result["metrics"]["exactPsnr"], 100.0)
        self.assertAlmostEqual(result["metrics"]["exactSsim"], 1.0, places=8)

    def test_disabled_noise_model_has_no_error_channels(self):
        model = _make_noise_model(
            NoiseSettings(
                enabled=False,
                eps_cx=0.0,
                t1_us=150,
                t2_us=100,
                cx_duration_ns=300,
                one_q_duration_ns=35,
            )
        )
        self.assertEqual(list(model.noise_instructions), [])

    def test_probability_projection_returns_valid_distribution(self):
        projected = _project_probability_simplex(np.array([-0.2, 0.25, 1.4, 0.1]))
        self.assertTrue(np.all(projected >= 0.0))
        self.assertAlmostEqual(float(projected.sum()), 1.0, places=12)

    def test_noisy_run_returns_cleaned_images_and_scores(self):
        size = 16
        y, x = np.mgrid[:size, :size]
        image = np.clip(0.15 + 0.02 * x + 0.015 * y, 0.0, 1.0)
        image[3:7, 4:8] = 0.95
        payload = SimulationRequest(
            size=size,
            channels=[image.ravel().tolist()],
            ordering="hilbert",
            chi=2,
            noise=NoiseSettings(
                enabled=True,
                eps_cx=0.001,
                t1_us=150,
                t2_us=100,
                cx_duration_ns=300,
                one_q_duration_ns=35,
            ),
        )
        result = _simulate(payload, lambda _event: None)
        self.assertTrue(result["mitigation"]["applied"])
        self.assertEqual(len(result["exactMitigated"]["channels"][0]), size * size)
        self.assertEqual(len(result["mpsMitigated"]["channels"][0]), size * size)
        for metric in (
            "exactMitigatedPsnr",
            "exactMitigatedSsim",
            "mpsMitigatedPsnr",
            "mpsMitigatedSsim",
        ):
            self.assertTrue(np.isfinite(result["metrics"][metric]))


if __name__ == "__main__":
    unittest.main()
