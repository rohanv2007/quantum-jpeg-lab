import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo } from "react";
import { Copy, Download } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CircuitDiagram, MetricValue, PixelCanvas, ProvenanceNote, StatusPill, Tag } from "@/components/qj/primitives";
import { ENV, fmtEps, orderingLabel, qubitsFor, resolveMetrics } from "@/lib/data";
import { setDraftConfig } from "@/lib/draft";
import { illustrate, sampleImage } from "@/lib/imagery";
import { fmtDate, useRuns, type StoredImage } from "@/lib/runs-store";

export const Route = createFileRoute("/_workbench/runs/$runId")({
  head: ({ params }) => ({
    meta: [
      { title: `Run ${params.runId} — Quantum JPEG` },
      { name: "description", content: "Run detail: image comparison, settings, fidelity and resource metrics, noise configuration and provenance." },
      { property: "og:title", content: `Run ${params.runId} — Quantum JPEG` },
      { property: "og:description", content: "Quantum JPEG run detail." },
    ],
  }),
  component: RunDetail,
});

function RunDetail() {
  const { runId } = Route.useParams();
  const runs = useRuns();
  const navigate = useNavigate();
  const run = runs.find((r) => r.id === runId);
  const imgs = useMemo(() => {
    if (!run) return null;
    if (run.simulation?.images) {
      const image = (stored: StoredImage) => ({
        size: stored.size,
        channels: stored.channels.map((channel) => Float32Array.from(channel)),
      });
      return {
        o: image(run.simulation.images.original),
        e: image(run.simulation.images.exact),
        i: run.simulation.images.mpsIdeal ? image(run.simulation.images.mpsIdeal) : null,
        p: image(run.simulation.images.mps),
        exactClean: run.simulation.images.exactMitigated ? image(run.simulation.images.exactMitigated) : null,
        mpsClean: run.simulation.images.mpsMitigated ? image(run.simulation.images.mpsMitigated) : null,
        mitigationMetrics: run.simulation.mitigationMetrics ?? null,
        m: run.simulation.metrics,
      };
    }
    const o = sampleImage(run.config.resolution, run.config.mode === "rgb");
    const m = run.simulation?.metrics ?? resolveMetrics(run.config);
    return {
      o,
      e: illustrate(o, { fidelity: m.exactNoisyF.measured ? Math.max(0.04, m.exactNoisyF.value) : 0.3, blockiness: 1, seed: 4 }),
      i: null,
      p: illustrate(o, { fidelity: m.mpsNoisyF.measured ? m.mpsNoisyF.value : 0.8, blockiness: ({ 1: 8, 2: 4, 4: 2, 8: 1 } as const)[run.config.chi], seed: 6 }),
      exactClean: null,
      mpsClean: null,
      mitigationMetrics: null,
      m,
    };
  }, [run]);

  if (!run || !imgs) {
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <p className="text-lg font-semibold">Run not found</p>
        <p className="mt-1 text-sm text-muted-foreground">No run with ID {runId} exists in this workspace.</p>
        <Button asChild className="mt-5" variant="outline"><Link to="/runs">Back to run history</Link></Button>
      </div>
    );
  }
  const c = run.config, m = imgs.m;
  const isRecord = run.kind === "benchmark";
  const isLocal = run.kind === "local" && !!run.simulation;
  const hasSavedImages = !!run.simulation?.images;
  const noiseActive = c.noise.enabled ?? true;

  const exportCircuit = () => {
    const q = qubitsFor(c.resolution);
    const txt = `# Quantum JPEG — prototype export (schematic, not a validated circuit)\n# run ${run.id} · ${q} qubits · ${c.ordering} · chi=${c.chi}\nfrom qiskit import QuantumCircuit, transpile\nfrom qiskit.circuit.library import Isometry\n\nqc = QuantumCircuit(${q})\n# for each site, right to left: qc.append(Isometry(V_site, 0, 0), qubits)\n# transpile(qc, basis_gates=[${c.basis.split(",").map((g) => `"${g.trim()}"`).join(", ")}], optimization_level=${c.optimizationLevel})\n`;
    const url = URL.createObjectURL(new Blob([txt], { type: "text/x-python" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${run.id}_circuit.py`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Prototype circuit script exported");
  };

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2"><span className="font-mono text-xs text-muted-foreground">{run.id}</span><StatusPill status={run.status} /><Tag tone={isLocal ? "cyan" : isRecord ? "measured" : "illustrative"}>{isLocal ? "Local Qiskit Aer result" : isRecord ? "Earlier benchmark record" : "Illustrative preview · not a benchmark"}</Tag></div>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">{run.name}</h2>
          <p className="mt-1 text-xs text-muted-foreground">{fmtDate(run.createdAt)}{run.note && ` · ${run.note}`}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-1.5" onClick={() => { setDraftConfig(c); navigate({ to: "/simulation" }); }}><Copy className="h-4 w-4" /> Duplicate configuration</Button>
          <Button className="gap-1.5" onClick={exportCircuit}><Download className="h-4 w-4" /> Export circuit template</Button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5">
          <section className="rounded-2xl border bg-card p-5">
            <div className="mb-4 flex items-center justify-between"><h3 className="text-sm font-semibold">Image comparison</h3><Tag tone={hasSavedImages ? "cyan" : "illustrative"}>{hasSavedImages ? "Saved local Aer reconstruction" : isLocal ? "Older local run · image snapshot not retained" : "Illustrative preview · not Aer output"}</Tag></div>
            <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
              {[["Original", imgs.o], [`Exact loader · ${noiseActive ? "noisy" : "ideal"}`, imgs.e], ...(imgs.i ? [[`MPS approximation · χ=${c.chi}`, imgs.i] as const] : []), [`MPS loader · χ=${c.chi} · ${noiseActive ? "noisy" : "ideal"}`, imgs.p]].map(([l, im]) => (
                <figure key={l as string}><PixelCanvas img={im as never} label={l as string} /><figcaption className="mt-2 text-xs font-medium">{l as string}</figcaption></figure>
              ))}
              {imgs.exactClean && imgs.mitigationMetrics && <figure><PixelCanvas img={imgs.exactClean} label="Exact cleaned estimate" /><figcaption className="mt-2 text-xs font-medium">Exact · cleaned estimate · SSIM {imgs.mitigationMetrics.exactSsim.toFixed(3)}</figcaption></figure>}
              {imgs.mpsClean && imgs.mitigationMetrics && <figure><PixelCanvas img={imgs.mpsClean} label="MPS cleaned estimate" /><figcaption className="mt-2 text-xs font-medium">MPS · cleaned estimate · SSIM {imgs.mitigationMetrics.mpsSsim.toFixed(3)}</figcaption></figure>}
            </div>
            {imgs.exactClean && <p className="mt-4 rounded-lg bg-cyan/5 p-3 text-xs leading-relaxed text-muted-foreground">Noise mitigation uses the saved noise settings to estimate a lower-noise result with zero-noise extrapolation. It is a model-based estimate, not automatic detection of unknown device noise. {run.simulation?.provenance.mitigationNote}</p>}
          </section>
          <section className="rounded-2xl border bg-card p-5">
            <div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-semibold">Circuit · sequential isometries</h3><span className="font-mono text-[11px] text-muted-foreground">schematic · {qubitsFor(c.resolution)} qubits</span></div>
            <CircuitDiagram qubits={qubitsFor(c.resolution)} chi={c.chi} />
          </section>
        </div>

        <div className="space-y-4">
          <section className="rounded-2xl border bg-card p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Metrics</h3>
            <div className="mt-3 space-y-2.5 text-xs">
              {[
                ["CNOTs/channel · exact", <MetricValue key="1" m={m.exactCnots} digits={0} />],
                ["CNOTs/channel · MPS", <MetricValue key="2" m={m.mpsCnots} digits={0} />],
                ["Ideal F · MPS", <MetricValue key="3" m={m.mpsIdealF} digits={3} />],
                [`${noiseActive ? "Noisy" : "Ideal"} F · exact`, <MetricValue key="4" m={m.exactNoisyF} />],
                [`${noiseActive ? "Noisy" : "Ideal"} F · MPS`, <MetricValue key="5" m={m.mpsNoisyF} />],
                ["PSNR · exact", <MetricValue key="6" m={m.exactPsnr} suffix=" dB" />],
                ["PSNR · MPS", <MetricValue key="7" m={m.mpsPsnr} suffix=" dB" />],
                ["SSIM · exact", <MetricValue key="8" m={m.exactSsim} />],
                ["SSIM · MPS", <MetricValue key="9" m={m.mpsSsim} />],
                ...(imgs.mitigationMetrics ? [
                  ["PSNR · exact cleaned", <span key="10" className="font-mono">{imgs.mitigationMetrics.exactPsnr.toFixed(2)} dB</span>],
                  ["SSIM · exact cleaned", <span key="11" className="font-mono">{imgs.mitigationMetrics.exactSsim.toFixed(3)}</span>],
                  ["PSNR · MPS cleaned", <span key="12" className="font-mono">{imgs.mitigationMetrics.mpsPsnr.toFixed(2)} dB</span>],
                  ["SSIM · MPS cleaned", <span key="13" className="font-mono">{imgs.mitigationMetrics.mpsSsim.toFixed(3)}</span>],
                ] as [string, React.ReactNode][] : []),
              ].map(([l, v]) => <div key={l as string} className="flex items-center justify-between"><span className="text-muted-foreground">{l}</span>{v}</div>)}
            </div>
            {isLocal && <p className="mt-3 border-t pt-3 font-mono text-[11px] leading-relaxed text-muted-foreground">{run.simulation!.provenance.engine} · Qiskit {run.simulation!.provenance.qiskitVersion} · Aer {run.simulation!.provenance.aerVersion} · {run.simulation!.provenance.elapsedSeconds}s on this PC.</p>}
            {!isLocal && m.anyMeasured && <ProvenanceNote className="mt-3 border-t pt-3" />}
          </section>
          <section className="rounded-2xl border bg-card p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Settings & noise</h3>
            <dl className="mt-3 grid grid-cols-2 gap-y-1.5 text-xs">
              {[
                ["Image", run.simulation?.provenance.imageName ?? (c.source === "camera" ? "procedural_sample" : c.uploadName ?? "upload")],
                ["Mode", c.mode], ["Resolution", `${c.resolution}×${c.resolution}`], ["Ordering", orderingLabel(c.ordering)], ["χ", c.chi],
                ["Noise", noiseActive ? `εcx ${fmtEps(c.noise.epsCx)}` : "Disabled (ideal)"], ["T1", `${c.noise.t1} µs`], ["T2", `${c.noise.t2} µs`], ["cx", `${c.noise.cxDuration} ns`], ["1q gate", `${c.noise.oneQDuration} ns`],
                ["Noise model", run.simulation?.provenance.noiseModelDescription ?? (noiseActive ? "Earlier run · model details not retained" : "Noise disabled")],
              ].map(([k, v]) => <div key={k as string} className="contents"><dt className="text-muted-foreground">{k}</dt><dd className="text-right font-mono">{v}</dd></div>)}
            </dl>
          </section>
          <section className="rounded-2xl border bg-card p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Provenance</h3>
            <dl className="mt-3 grid grid-cols-2 gap-y-1.5 text-xs">
              {[["Qiskit", run.simulation?.provenance.qiskitVersion ?? ENV.qiskit], ["Aer", run.simulation?.provenance.aerVersion ?? ENV.aer], ["Simulator", isLocal ? "Local Aer · density_matrix · " + run.simulation!.provenance.device : ENV.method], ["Basis", c.basis], ["Opt. level", c.optimizationLevel], ["Source", isLocal ? "Computed on this PC" : isRecord ? "Earlier sandbox run" : "Illustrative UI"]].map(([k, v]) => (
                <div key={k as string} className="contents"><dt className="text-muted-foreground">{k}</dt><dd className="text-right font-mono">{v}</dd></div>
              ))}
            </dl>
          </section>
        </div>
      </div>
    </div>
  );
}
