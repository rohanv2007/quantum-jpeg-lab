import { useEffect, useRef, useState } from "react";
import { CheckCircle2, ImageIcon, Loader2, Play, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PixelCanvas } from "@/components/qj/primitives";
import { DEFAULT_NOISE, fmtEps, orderingLabel, type Chi, type Ordering } from "@/lib/data";
import { imageFromFile, sampleImage, type Img } from "@/lib/imagery";
import { runLocalEngine } from "@/lib/local-engine";
import { saveLocalResult, type LocalResult } from "@/lib/local-bench";

export interface TestTarget { key: string; qubits: 8 | 10; eps: number; ordering: Ordering; chi: Chi }

const STAGES = ["Preprocessing", "MPS truncation", "Circuit synthesis", "Aer noise simulation", "Reconstruction", "Scoring"];

export function RunTestDialog({ target, onClose }: { target: TestTarget | null; onClose: () => void }) {
  const [img, setImg] = useState<Img | null>(null);
  const [name, setName] = useState("Sample camera tile");
  const [stage, setStage] = useState(-1);
  const [result, setResult] = useState<LocalResult | null>(null);
  const [detail, setDetail] = useState("");
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const size = target?.qubits === 8 ? 16 : 32;

  useEffect(() => {
    if (!target) return;
    setImg(sampleImage(target.qubits === 8 ? 16 : 32));
    setName("Procedural sample tile");
    setStage(-1);
    setResult(null);
    setDetail("");
    setError("");
  }, [target]);

  const onFile = async (f?: File) => {
    if (!f) return;
    if (!/image\/(png|jpeg|webp)/.test(f.type)) {
      toast.error("Unsupported file", { description: "Use PNG, JPEG or WebP." });
      return;
    }
    if (f.size > 8 * 1024 * 1024) {
      toast.error("File too large", { description: "Maximum size is 8 MB." });
      return;
    }
    try { setImg(await imageFromFile(f, size, false)); setName(f.name); }
    catch { toast.error("Could not read that image. Try a PNG or JPG."); }
  };

  const run = async () => {
    if (!target || !img) return;
    setResult(null);
    setError("");
    setStage(0);
    setDetail("Starting a simulation on this PC.");
    try {
      const response = await runLocalEngine({
        image: img,
        imageName: name,
        ordering: target.ordering,
        chi: target.chi,
        noise: { ...DEFAULT_NOISE, epsCx: target.eps },
        basis: "rz, sx, x, cx",
        optimizationLevel: 1,
      }, (event) => {
        if (event.type === "stage") {
          setStage(event.stage);
          setDetail(event.detail);
        } else {
          setDetail(`Aer is calculating on this PC · ${event.elapsedSeconds}s elapsed`);
        }
      });
      const r: LocalResult = {
        key: target.key,
        exact: { fidelity: response.metrics.exactNoisyFidelity, cnots: Math.round(response.metrics.exactCnots) },
        mps: { fidelity: response.metrics.mpsNoisyFidelity, cnots: Math.round(response.metrics.mpsCnots) },
        idealFidelity: response.metrics.mpsIdealFidelity,
        psnr: response.metrics.mpsPsnr,
        ssim: response.metrics.mpsSsim,
        image: name,
        ordering: target.ordering,
        chi: target.chi,
        qiskitVersion: response.provenance.qiskitVersion,
        aerVersion: response.provenance.aerVersion,
        device: response.provenance.device,
        noiseModelDescription: response.provenance.noiseModelDescription,
        createdAt: new Date().toISOString(),
      };
      saveLocalResult(r);
      setStage(STAGES.length);
      setDetail(`Completed locally with Qiskit ${r.qiskitVersion} and Aer ${r.aerVersion}.`);
      setResult(r);
      toast.success("Local Aer run complete — result added to the table");
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "The local simulation failed.";
      setStage(-1);
      setError(message);
      setDetail("");
      toast.error("Local simulation failed", { description: message });
    }
  };

  const running = stage >= 0 && stage < STAGES.length;

  return (
    <Dialog open={!!target} onOpenChange={(o) => !o && !running && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Run benchmark test</DialogTitle>
          <DialogDescription className="font-mono text-xs">
            {target && `${target.qubits} qubits (${size}×${size}) · εcx ${fmtEps(target.eps)} · ${orderingLabel(target.ordering)} · χ=${target.chi}`}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-5 sm:grid-cols-[180px_1fr]">
          <div className="space-y-2">
            <div className="overflow-hidden rounded-xl border bg-muted">{img ? <PixelCanvas img={img} className="aspect-square w-full" /> : <div className="flex aspect-square items-center justify-center"><ImageIcon className="h-6 w-6 text-muted-foreground" /></div>}</div>
            <p className="truncate text-[11px] text-muted-foreground">{name}</p>
            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1 gap-1.5" disabled={running} onClick={() => fileRef.current?.click()}><Upload className="h-3.5 w-3.5" /> Upload</Button>
              <Button size="sm" variant="ghost" disabled={running} onClick={() => { setImg(sampleImage(size)); setName("Procedural sample tile"); }}>Sample</Button>
            </div>
          </div>

          <div className="space-y-3">
            <ol className="space-y-1.5 text-xs">
              {STAGES.map((s, i) => (
                <li key={s} className="flex items-center gap-2">
                  {stage > i ? <CheckCircle2 className="h-3.5 w-3.5 text-success" /> : stage === i ? <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" /> : <span className="h-3.5 w-3.5 rounded-full border" />}
                  <span className={stage >= i ? "text-foreground" : "text-muted-foreground"}>{s}</span>
                </li>
              ))}
            </ol>
            {stage >= 0 && <div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary transition-all" style={{ width: `${(Math.min(stage, STAGES.length) / STAGES.length) * 100}%` }} /></div>}
            {detail && <p className="text-[11px] leading-relaxed text-muted-foreground">{detail}</p>}
            {error && <p role="alert" className="rounded-lg bg-destructive/5 p-2 text-xs text-destructive">{error}</p>}

            {result && (
              <div className="grid grid-cols-2 gap-2 rounded-xl border bg-muted/40 p-3 font-mono text-xs">
                <div><p className="text-muted-foreground">MPS noisy fidelity</p><p className="text-base font-semibold text-primary">{result.mps.fidelity.toFixed(4)}</p><p className="text-muted-foreground">{result.mps.cnots} CNOTs</p></div>
                <div><p className="text-muted-foreground">Exact noisy fidelity</p><p className="text-base font-semibold">{result.exact.fidelity.toFixed(4)}</p><p className="text-muted-foreground">{result.exact.cnots} CNOTs</p></div>
                <p className="col-span-2 text-[11px] text-muted-foreground">Ideal MPS fidelity {result.idealFidelity.toFixed(4)} · PSNR {result.psnr.toFixed(2)} dB · SSIM {result.ssim.toFixed(4)} · {result.device} · Qiskit {result.qiskitVersion} / Aer {result.aerVersion}</p>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="ghost" disabled={running} onClick={onClose}>{result ? "Done" : "Cancel"}</Button>
          <Button className="gap-1.5" disabled={!img || running} onClick={run}>{running ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}{result ? "Run again" : "Run test on this PC"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
