import type { Chi, Ordering, NoiseConfig } from "./data";
import type { Img } from "./imagery";

export interface LocalEngineInput {
  image: Img;
  imageName: string;
  ordering: Ordering;
  chi: Chi;
  noise: NoiseConfig;
  basis: string;
  optimizationLevel: number;
}

export interface EngineMetrics {
  exactCnots: number;
  mpsCnots: number;
  exactNoisyFidelity: number;
  mpsNoisyFidelity: number;
  mpsIdealFidelity: number;
  circuitVsMps: number;
  exactPsnr: number;
  mpsPsnr: number;
  exactSsim: number;
  mpsSsim: number;
  exactMitigatedPsnr: number;
  exactMitigatedSsim: number;
  mpsMitigatedPsnr: number;
  mpsMitigatedSsim: number;
}

export interface LocalEngineResult {
  exact: { channels: number[][] };
  mpsIdeal: { channels: number[][] };
  mps: { channels: number[][] };
  exactMitigated: { channels: number[][] } | null;
  mpsMitigated: { channels: number[][] } | null;
  mitigation: { applied: boolean; method: string; note: string };
  metrics: EngineMetrics;
  provenance: {
    engine: string;
    qiskitVersion: string;
    aerVersion: string;
    device: string;
    numpyVersion: string;
    scikitImageVersion: string;
    imageName: string;
    channelEncoding: string;
    ordering: Ordering;
    chi: Chi;
    noise: {
      enabled: boolean;
      eps_cx: number;
      t1_us: number;
      t2_us: number;
      cx_duration_ns: number;
      one_q_duration_ns: number;
    };
    basis: string[];
    optimizationLevel: number;
    noiseApplied: boolean;
    noiseModelDescription: string;
    perChannel: Array<Record<string, string | number>>;
    elapsedSeconds: number;
  };
}

export interface LocalEngineHealth {
  status: string;
  engine: string;
  qiskit: string;
  aer: string;
  numpy: string;
  devices: string[];
  defaultDevice: string;
}

export type LocalEngineEvent =
  | { type: "stage"; stage: number; label: string; detail: string }
  | { type: "heartbeat"; elapsedSeconds: number };

const ENGINE_URL = "http://127.0.0.1:8765";

export async function getLocalEngineHealth(signal?: AbortSignal): Promise<LocalEngineHealth> {
  const response = await fetch(ENGINE_URL + "/api/health", signal ? { signal } : {});
  if (!response.ok) throw new Error("Local engine returned " + response.status + ".");
  return response.json() as Promise<LocalEngineHealth>;
}

function errorText(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object") {
    const item = payload as { detail?: unknown; message?: unknown };
    if (typeof item.detail === "string") return item.detail;
    if (typeof item.message === "string") return item.message;
  }
  return fallback;
}

function decodeFrame(frame: string): unknown | null {
  const data = frame
    .split(/\r?\n/)
    .filter((line) => line.startsWith("data:"))
    .map((line) => line.slice(5).trimStart())
    .join("\n");
  return data ? JSON.parse(data) : null;
}

export async function runLocalEngine(
  input: LocalEngineInput,
  onEvent: (event: LocalEngineEvent) => void,
  signal?: AbortSignal,
): Promise<LocalEngineResult> {
  let response: Response;
  try {
    response = await fetch(`${ENGINE_URL}/api/simulate/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        size: input.image.size,
        channels: input.image.channels.map((channel) => Array.from(channel)),
        ordering: input.ordering,
        chi: input.chi,
        noise: {
          enabled: input.noise.enabled,
          eps_cx: input.noise.epsCx,
          t1_us: input.noise.t1,
          t2_us: input.noise.t2,
          cx_duration_ns: input.noise.cxDuration,
          one_q_duration_ns: input.noise.oneQDuration,
        },
        basis: input.basis,
        optimization_level: input.optimizationLevel,
        image_name: input.imageName,
      }),
      ...(signal ? { signal } : {}),
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    throw new Error("Could not reach the local Qiskit service. Start it with the project’s local setup instructions, then run again.");
  }

  if (!response.ok) {
    let payload: unknown;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
    throw new Error(errorText(payload, `The local Qiskit service returned ${response.status}.`));
  }
  if (!response.body) throw new Error("The local Qiskit service did not return a progress stream.");

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let result: LocalEngineResult | null = null;

  const handleFrame = (frame: string) => {
    const parsed = decodeFrame(frame);
    if (!parsed || typeof parsed !== "object") return;
    const event = parsed as {
      type?: unknown;
      stage?: unknown;
      label?: unknown;
      detail?: unknown;
      elapsedSeconds?: unknown;
      message?: unknown;
      result?: unknown;
    };
    if (event.type === "stage" && typeof event.stage === "number") {
      onEvent({
        type: "stage",
        stage: event.stage,
        label: typeof event.label === "string" ? event.label : "Processing",
        detail: typeof event.detail === "string" ? event.detail : "Working on this PC.",
      });
    } else if (event.type === "heartbeat" && typeof event.elapsedSeconds === "number") {
      onEvent({ type: "heartbeat", elapsedSeconds: event.elapsedSeconds });
    } else if (event.type === "error") {
      throw new Error(typeof event.message === "string" ? event.message : "The local simulation failed.");
    } else if (event.type === "result" && event.result && typeof event.result === "object") {
      result = event.result as LocalEngineResult;
    }
  };

  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      const frames = buffer.split(/\r?\n\r?\n/);
      buffer = frames.pop() ?? "";
      for (const frame of frames) handleFrame(frame);
      if (done) break;
    }
    if (buffer.trim()) handleFrame(buffer);
  } finally {
    reader.releaseLock();
  }

  if (!result) throw new Error("The local simulation ended before returning results.");
  return result;
}

export function imageFromEngineChannels(size: number, channels: number[][]): Img {
  return { size, channels: channels.map((channel) => Float32Array.from(channel)) };
}
