import { useSyncExternalStore } from "react";
import type { Chi, Ordering } from "./data";

/** A benchmark result computed by the local Python/Qiskit Aer service. */
export interface LocalResult {
  key: string;
  exact: { fidelity: number; cnots: number };
  mps: { fidelity: number; cnots: number };
  idealFidelity: number;
  psnr: number;
  ssim: number;
  image: string;
  ordering: Ordering;
  chi: Chi;
  qiskitVersion: string;
  aerVersion: string;
  device: string;
  noiseModelDescription: string;
  createdAt: string;
}

// Model v3 removes the old, implicit εcx/10 one-qubit depolarizing error and
// treats RZ as a virtual zero-duration gate. Do not mix old local results in.
const KEY = "qjpeg.localbench.v3";
let store: Record<string, LocalResult> = {};
let loaded = false;
const listeners = new Set<() => void>();
const EMPTY: Record<string, LocalResult> = {};

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    store = JSON.parse(localStorage.getItem(KEY) || "{}");
  } catch {
    store = {};
  }
}

export function saveLocalResult(result: LocalResult) {
  load();
  store = { ...store, [result.key]: result };
  try {
    localStorage.setItem(KEY, JSON.stringify(store));
  } catch {
    /* Keep the in-memory result visible if browser storage is full or unavailable. */
  }
  listeners.forEach((listener) => listener());
}

export function useLocalResults(): Record<string, LocalResult> {
  return useSyncExternalStore(
    (listener) => {
      load();
      listeners.add(listener);
      listener();
      return () => listeners.delete(listener);
    },
    () => store,
    () => EMPTY,
  );
}
